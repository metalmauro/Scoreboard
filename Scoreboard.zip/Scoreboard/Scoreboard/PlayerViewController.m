//
//  PlayerViewController.m
//  Scoreboard
//
//  Created by Matthew Mauro on 2016-11-21.
//  Copyright © 2016 Matthew Mauro. All rights reserved.
//

#import "PlayerViewController.h"

@interface PlayerViewController ()
@property (weak, nonatomic) IBOutlet UILabel *shotValue;
@property (weak, nonatomic) IBOutlet UILabel *shot2Value;
@property (weak, nonatomic) IBOutlet UILabel *shot3Value;
@property (strong, nonatomic) IBOutletCollection(UIButton) NSArray *boardSpaces;
@property (strong, nonatomic) IBOutletCollection(UIImageView) NSArray *closeImages;
@property (weak, nonatomic) IBOutlet UIButton *setScoreButton;
@property (weak, nonatomic) IBOutlet UIImageView *multiplierImage;
@property NSString *shotInput;
@property NSInteger shotCount;
@property NSInteger multiplier;
@end

@implementation PlayerViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    self.view.backgroundColor = [UIColor darkGrayColor];
    if((self.pageIndex % 2)==0)
    {
        self.imageFile = @"oddBoard";
        self.playerLabel.textAlignment = NSTextAlignmentLeft;
        for(UIButton *button in self.boardSpaces){
            button.titleLabel.textAlignment = NSTextAlignmentLeft;
        }
    }else{
        self.imageFile = @"evenBoard";
        self.playerLabel.textAlignment = NSTextAlignmentRight;
        for(UIButton *button in self.boardSpaces){
            button.titleLabel.textAlignment = NSTextAlignmentRight;
        }
    }
    [self setInteractivity:NO];
    self.setScoreButton.backgroundColor = [UIColor colorWithRed:240.0f/255.0f green:121.0f/255.0f blue:17.0f/255.0f alpha:1];
    self.shotCount = 1;
    self.multiplier = 0;
    self.multiplierImage.image = [self setMultiplierImage];
    self.shotValue.text = @"";
    self.shot2Value.text = @"";
    self.shot3Value.text = @"";
    self.boardImage.image = [UIImage imageNamed:self.imageFile];
    [self.player updateScore];
    self.scoreLabel.text = [NSString stringWithFormat:@"%@",self.player.score];
    self.playerLabel.text = self.player.name;
    for(UIButton *button in self.boardSpaces){
        [button addTarget:self action:@selector(makeShot:) forControlEvents:UIControlEventTouchUpInside];
        button.userInteractionEnabled = YES;
    }
    for (id key in self.player.shots) {
        NSInteger previouslyHit = [[self.player.shots objectForKey:key]integerValue];
        if ([key isEqualToString:@"bull"]) {
            [self checkIfClosed:14 andTimesHit:previouslyHit];
        }else{
            [self checkIfClosed:[key integerValue] andTimesHit:previouslyHit];
        }
    }
}
-(void)setInteractivity:(BOOL)toSet
{
    if (toSet == YES) {
        self.setScoreButton.hidden = NO;
        self.setScoreButton.userInteractionEnabled = YES;
    }else{
        self.setScoreButton.hidden = YES;
        self.setScoreButton.userInteractionEnabled = NO;
    }
}
//returns multiplier image to set by ImageView
-(UIImage*)setMultiplierImage
{
    switch (self.multiplier) {
        case 1:
            return [UIImage imageNamed:@"single"];
            break;
        case 2:
            return [UIImage imageNamed:@"double"];
            break;
        case 3:
            return [UIImage imageNamed:@"triple"];
            break;
    }
    return nil;
}


#pragma mark - Select Shot Value and Multiplier
// Fires when user taps button cooresponding to dartBoard slice
// tap multiple times to cycle through the multiplier values
-(void)makeShot:(UIButton*)sender
{
    [self setInteractivity:YES];
    self.multiplier++;
    if(self.multiplier == 4)
    {
        self.multiplier = 0;
    }
    self.shotInput = sender.restorationIdentifier;
    [self updateScoreValues:self.shotInput];
    self.multiplierImage.image = [self setMultiplierImage];
}


//UILabel function
-(void)updateScoreValues:(NSString*)shotScore;
{
    switch (self.shotCount) {
        case 1:
            self.shotValue.text = shotScore;
            break;
        case 2:
            self.shot2Value.text = shotScore;
            break;
        case 3:
            self.shot3Value.text = shotScore;
            break;
        case 4:
            self.setScoreButton.titleLabel.text = @"New Round";
            self.setScoreButton.backgroundColor = [UIColor redColor];
            for (UIButton *button in self.boardSpaces) {
                button.userInteractionEnabled = NO;
            }
            break;
    }
}

#pragma mark - Finalize Score Method

- (IBAction)finalizeScore:(UIButton *)sender {
    if (self.shotCount == 4) {
        [self viewDidLoad];
    }else{
        
        //get number of times previously hit from Dictionary
        NSInteger number = [[self.player.shots objectForKey:self.shotInput]integerValue];
        for (int i = 0; i < self.multiplier; i++) {
            number++;
        }
        
        //finalValue simply used to update the 3 shot labels
        NSString *finalValue = [NSString stringWithFormat:@"%@, x%ld", self.shotInput, self.multiplier];
        [self updateScoreValues:(finalValue)];
        self.shotCount++;
        
        //set new number in player's dictionary for shotInput key
        [self.player.shots setObject:[NSNumber numberWithInteger:number] forKey:self.shotInput];
        //basic resets
        [self setInteractivity:NO];
        self.multiplier = 0;
        self.multiplierImage.image = [self setMultiplierImage];
        
        // iterate through shots dictionary to see if the spaces are closed
        for (id key in self.player.shots) {
            NSInteger previouslyHit = [[self.player.shots objectForKey:key]integerValue];
            
            //bull isn't a numerical value
            if ([key isEqualToString:@"bull"]) {
                [self checkIfClosed:25 andTimesHit:previouslyHit];
            }else{
                [self checkIfClosed:[key integerValue] andTimesHit:previouslyHit];
            }
        }
        
        
        // have the player return it's score based on it's dictionary
        [self.player updateScore];
        self.scoreLabel.text = [NSString stringWithFormat:@"%@",self.player.score];
        self.shotInput = @"";
    }
}

// set imageViews for hit symbols
-(UIImageView*)checkIfClosed:(NSInteger)key andTimesHit:(NSInteger)hit
{
    UIImageView *new = [UIImageView new];
    for(UIImageView *imageView in self.closeImages)
    {
        if (imageView.tag == key) {
            switch (hit) {
                case 0:
                    imageView.image = nil;
                    return imageView;
                    break;
                case 1:
                    imageView.image = [UIImage imageNamed:@"single"];
                    return imageView;
                    break;
                case 2:
                    imageView.image = [UIImage imageNamed:@"double"];
                    return imageView;
                    break;
                case 3:
                    imageView.image = [UIImage imageNamed:@"triple"];
                    return imageView;
                    break;
                default:
                    imageView.image = [UIImage imageNamed:@"triple"];
                    self.scoreLabel.text = [NSString stringWithFormat:@"%@", self.player.score];
                    return imageView;
                    break;
            }
        }
    }
    return new;
}




/*
 #pragma mark - Navigation
 
 // In a storyboard-based application, you will often want to do a little preparation before navigation
 - (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
 // Get the new view controller using [segue destinationViewController].
 // Pass the selected object to the new view controller.
 }
 */

@end
