//
//  Player.m
//  Scoreboard
//
//  Created by Matthew Mauro on 2016-11-21.
//  Copyright © 2016 Matthew Mauro. All rights reserved.
//

#import "Player.h"

@implementation Player

- (instancetype)init
{
    self = [super init];
    if (self) {
        _score = @0;
        _shots = [NSMutableDictionary new];
        int sl = 20;
        for (int i = 0; i <= 6; i++) {
            int slice = sl - i;
            if (slice == 14) {
                [self.shots setObject:@0 forKey:@"bull"];
            }else{
                [self.shots setObject:@0 forKey:[NSString stringWithFormat:@"%d", slice]];
            }
        }
        
    }
    return self;
}
-(void)updateScore
{
    NSInteger score = [self.score integerValue];
    for(id key in self.shots)
    {
        NSInteger bull = 25;
        NSInteger previousHits = [self.shots[key]integerValue];
        
        if (previousHits <= 3) {
            previousHits = 0;
        }
        if ([key isEqualToString:@"bull"]) {
            NSInteger roundScore = bull*(previousHits-3);
            score+=roundScore;
        }else{
            NSInteger roundScore = [key integerValue]*(previousHits-3);
            score+=roundScore;
        }
    }
    self.score = [NSNumber numberWithInteger:score];
}
@end
