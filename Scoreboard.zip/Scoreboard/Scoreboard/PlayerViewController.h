//
//  PlayerViewController.h
//  Scoreboard
//
//  Created by Matthew Mauro on 2016-11-21.
//  Copyright © 2016 Matthew Mauro. All rights reserved.
//
#import "Player.h"
#import <UIKit/UIKit.h>

@interface PlayerViewController : UIViewController
@property (weak, nonatomic) IBOutlet UIImageView *boardImage;
@property (weak, nonatomic) IBOutlet UILabel *playerLabel;
@property (weak, nonatomic) IBOutlet UILabel *scoreLabel;

@property Player *player;
@property NSInteger pageIndex;
@property NSString *titleText;
@property NSString *imageFile;

@end
