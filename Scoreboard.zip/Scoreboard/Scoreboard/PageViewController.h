//
//  PageViewController.h
//  Scoreboard
//
//  Created by Matthew Mauro on 2016-11-21.
//  Copyright © 2016 Matthew Mauro. All rights reserved.
//
#import "PlayerViewController.h"
#import <UIKit/UIKit.h>

@interface PageViewController : UIPageViewController <UIPageViewControllerDataSource>
@property PlayerViewController *playerViewController;
@property NSInteger pageIndex;
@property NSMutableArray *players;
@property (strong, nonatomic) NSMutableArray *viewCs;

@end
