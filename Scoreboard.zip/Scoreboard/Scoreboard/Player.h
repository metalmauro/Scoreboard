//
//  Player.h
//  Scoreboard
//
//  Created by Matthew Mauro on 2016-11-21.
//  Copyright © 2016 Matthew Mauro. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface Player : NSObject
@property (strong, nonatomic) NSNumber *score;
@property NSString *name;
@property NSMutableDictionary *shots;
-(void)updateScore;
@end
