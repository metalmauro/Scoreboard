//
//  ViewController.m
//  Scoreboard
//
//  Created by Matthew Mauro on 2016-11-21.
//  Copyright © 2016 Matthew Mauro. All rights reserved.
//
#import "Player.h"
#import "ViewController.h"
#import "PageViewController.h"

@interface ViewController ()

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    self.players = [NSMutableArray new];
    self.playerCount.delegate = self;
    self.playerCount.dataSource = self;
    
    self.pageViewController = [UIPageViewController new];
}

-(void)setPlayerAmount
{
    NSInteger picked = [self.playerCount selectedRowInComponent:0];
    for(int i = 0; i <= picked; i++)
    {
        Player *new = [[Player alloc]init];
        new.name = [NSString stringWithFormat:@"Player %d", i+1];
        [self.players addObject:new];
    }
}

#pragma mark - Segues
-(void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender
{
    [self setPlayerAmount];
    PageViewController *pVC = (PageViewController*)[segue destinationViewController];
    pVC.players = self.players;
    pVC.pageIndex = 0;
}
#pragma mark - PickerView

-(NSInteger)numberOfComponentsInPickerView:(UIPickerView *)pickerView
{
    return 1;
}
-(NSString *)pickerView:(UIPickerView *)pickerView titleForRow:(NSInteger)row forComponent:(NSInteger)component
{
    NSString *rowLabel;
    switch (row) {
        case 0:
            rowLabel = @"Single Player";
            break;
        case 1:
            rowLabel = @"2 Players";
            break;
        case 2:
            rowLabel = @"3 Players";
            break;
        case 3:
            rowLabel = @"4 Players";
            break;
    }
    return rowLabel;
}
-(NSInteger)pickerView:(UIPickerView *)pickerView numberOfRowsInComponent:(NSInteger)component
{
    return 4;
}


@end
