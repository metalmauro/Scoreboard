//
//  PageViewController.m
//  Scoreboard
//
//  Created by Matthew Mauro on 2016-11-21.
//  Copyright © 2016 Matthew Mauro. All rights reserved.
//

#import "PageViewController.h"

@interface PageViewController () 

@end

@implementation PageViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    self.dataSource = self;
    NSInteger gameSize = [self.players count];
    for(int x =0; x < gameSize; x++)
    {
        PlayerViewController *board = [self.storyboard instantiateViewControllerWithIdentifier:@"PlayerContent"];
        [self.viewCs addObject:board];
    }
    self.playerViewController = [self viewControllerAtIndex:0];
//    [self addChildViewController:self.playerViewController];
    [self setViewControllers:@[self.playerViewController] direction:UIPageViewControllerNavigationDirectionForward animated:YES completion:nil];
    
}
-(void)viewWillAppear:(BOOL)animated
{
    [super viewWillAppear:YES];
    self.viewCs = [NSMutableArray new];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}


#pragma mark - Navigation

- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    
}

#pragma mark - PageView DataSource
- (UIViewController *)pageViewController:(UIPageViewController *)pageViewController viewControllerBeforeViewController:(UIViewController *)viewController
{
    NSUInteger index = ((PlayerViewController*) viewController).pageIndex;
    if ((index == 0) || (index == NSNotFound)) {
        return nil;
    }
    index--;
    return [self viewControllerAtIndex:index];
}
- (UIViewController *)pageViewController:(UIPageViewController *)pageViewController viewControllerAfterViewController:(UIViewController *)viewController
{
    NSUInteger index = ((PlayerViewController*) viewController).pageIndex;
    if (index == NSNotFound) {
        return nil;
    }
    index++;
    if (index == [self.players count]) {
        return nil;
    }
    return [self viewControllerAtIndex:index];
}
- (PlayerViewController *)viewControllerAtIndex:(NSUInteger)index
{
    if (([self.players count] == 0) || (index >= [self.players count])) {
        return nil;
    }
    PlayerViewController *pageContentViewController = [self.storyboard instantiateViewControllerWithIdentifier:@"PlayerContent"];
    pageContentViewController.pageIndex = index;
    pageContentViewController.player = [self.players objectAtIndex:index];
    return pageContentViewController;
}
- (NSInteger)presentationCountForPageViewController:(UIPageViewController *)pageViewController
{
    return [self.players count];
}
- (NSInteger)presentationIndexForPageViewController:(UIPageViewController *)pageViewController
{
    return 0;
}
-(NSString*)findPlayerName:(NSUInteger)index
{
    Player *p = [self.players objectAtIndex:index];
    return p.name;
}

@end
