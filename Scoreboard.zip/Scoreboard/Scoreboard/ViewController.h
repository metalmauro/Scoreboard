//
//  ViewController.h
//  Scoreboard
//
//  Created by Matthew Mauro on 2016-11-21.
//  Copyright © 2016 Matthew Mauro. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ViewController : UIViewController <UIPickerViewDelegate, UIPickerViewDataSource>
@property (strong, nonatomic) UIPageViewController *pageViewController;
@property (weak, nonatomic) IBOutlet UIPickerView *playerCount;
@property (strong) NSMutableArray *players;
-(void)setPlayerAmount;

@end

